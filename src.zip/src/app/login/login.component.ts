import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm:any;
  status:any;
  constructor(private fb:FormBuilder, private us:UserService, private router:Router) {
    this.loginForm=this.fb.group({
      userName:[''],
      password:[''],
      showPassword:[false]
    });
   }

  ngOnInit(): void {
  }

  fnLogin()
  {
    var userName=this.loginForm.controls.userName.value;
    var password=this.loginForm.controls.password.value;
    console.log(userName+":"+password);
    const formData=new FormData();
    formData.append('userName',userName);
    formData.append('password',password);
    this.us.validateLogin(formData).subscribe(data=>{
      console.log(data);
      if(data==null)
        this.status="Login failed";
      else
      {
        this.router.navigate([{outlets:{'col3':['home']}}]);        
        // this.router.navigateByUrl('/(col3:home)');
      }
    });
  }

}
